# KTH-Dataset
Experimenting with the KTH human activity recognition dataset from http://www.nada.kth.se/cvap/actions/
